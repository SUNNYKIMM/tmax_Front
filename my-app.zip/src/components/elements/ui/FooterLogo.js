

export default function FooterLogo(){
    return(
        <div className="col-12 col-md-3">
            <p className="footerLogo">Crayon<br/><span>SHINCHAN</span><br/>by Yoshito Usui</p>
            <p className="copy">© 2021 Crayon Shinchan .All Rights Reserved</p>
        </div>
    );
}